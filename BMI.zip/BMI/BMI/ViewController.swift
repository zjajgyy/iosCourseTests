//
//  ViewController.swift
//  BMI
//
//  Created by zjajgyy on 2016/11/23.
//  Copyright © 2016年 zjajgyy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var bmiData: UILabel!
    @IBOutlet weak var bmiText: UILabel!
    @IBOutlet weak var unitSegmentControl: UISegmentedControl!
    @IBOutlet weak var heightTextField: UITextField!
    @IBOutlet weak var weightTextField: UITextField!
    @IBOutlet weak var heightUnit: UILabel!
    @IBOutlet weak var weightUnit: UILabel!
    var unitIndex: NSInteger! = 0
    var height: Double! = 0
    var weight: Double! = 0
    var bmi: Double! = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    

    @IBAction func unitSegmentAction(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex==0 {
            unitIndex = 0
            heightUnit.text = "m"
            weightUnit.text = "kg"
        } else if sender.selectedSegmentIndex==1 {
            unitIndex = 1
            heightUnit.text = "inch"
            weightUnit.text = "lbs"
        }

    }
 
    
    @IBAction func calculate(_ sender: Any) {
        if let heightText = heightTextField.text, let weightText = weightTextField.text, !heightText.isEmpty && !weightText.isEmpty {
            height = Double(heightText)
            weight = Double(weightText)
            if unitIndex == 0 {
                bmi = Double(weight/height)/height
            } else if unitIndex == 1 {
                bmi = Double(weight/height)/height*703
            }
            bmiData.text = String(format: "%0.1f", bmi)
            if bmi < 18 {
                bmiText.text = "underweight"
            } else if bmi < 18.5 {
                bmiText.text = "thin for height"
            } else if bmi < 24.9 {
                bmiText.text = "healthy weight"
            } else if bmi < 29.9 {
                bmiText.text = "overweight"
            } else if bmi > 30 {
                bmiText.text = "obese"
            }
        } else {
            //alertcontroller
            let alertController = UIAlertController(title: "Data missing", message: "Height or Weight is empty", preferredStyle: .alert)//2 styles: .alert and .action...
            
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil) //create an OK button
            
            alertController.addAction(okAction)
            
            // display the alert box
            self.present(alertController, animated: true, completion: nil)
            
        }
        //        guard let heightText = heightTextField.text, let weightText = weightTextField.text, !heightText.isEmpty && !weightText.isEmpty,
        //            let height = Double(heightText) else {
        //                //
        //                return
        //        }
        
        //continue
        /*if bmi <= 24.9 {
         
         } else if {
         
         }*/
        
        //BMILabel.text = String(format: "%.1f", bmi)

    }

}

