//
//  IFImage.swift
//  ImageFetcher
//
//  Created by Yanping Zhao on 11/28/16.
//  Copyright © 2016 Yanping Zhao. All rights reserved.
//

import Foundation
import UIKit

class IFImage: NSObject {
    var imageName: String
    var imageURL: URL?
    
    var image: UIImage? {// computed property
        get {
            if imageData == nil {
                fetchAsync()
                
                return UIImage(named: "photoalbum")
            } else {
                return UIImage(data: imageData!)
            }
        }
    }
    
    private var imageData: Data?
    
    private func fetchAsync() {
        
    }
    
    init(name: String, url: URL?) {
        self.imageName = name
        self.imageURL = url
        
        super.init()
    }
}
