//
//  ListViewController.swift
//  ImageFetcher
//
//  Created by Yanping Zhao on 11/27/16.
//  Copyright © 2016 Yanping Zhao. All rights reserved.
//

import UIKit

extension UIViewController {
    var contentViewController: UIViewController {
        if let navController = self as? UINavigationController {
            return navController.topViewController ?? self
        } else {
            return self
        }
    }
}

class ListViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var pickerView: UIPickerView!
    
    let images = [["imageName": "wet land", "imageURL": "http://127.0.0.1/PhotoAlbum/b01.jpg"],
                  ["imageName": "Great Wall of China", "imageURL": "http://up.qin180.com/2014/0326/20140326110836781.jpg"],["imageName": "TianAnMen Square", "imageURL": "http://military.people.com.cn/NMediaFile/2016/0102/MAIN201601021010000399701943600.jpg"]]
    
    private struct identifiers {
        static let ShowPicture = "ShowPicture"
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == identifiers.ShowPicture {
            if let imageVC = segue.destination.contentViewController as? ImageViewController {
                imageVC.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem
                imageVC.navigationItem.leftItemsSupplementBackButton = true
                
                let rowIndex = pickerView.selectedRow(inComponent: 0)
        
                //TODO: passing data
            }
        }
    }
    
    // MARK: - UIPickerViewDataSource
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return images.count
    }
    
    // MARK: - UIPickerViewDelegate
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return images[row]["imageName"]
    }
}
