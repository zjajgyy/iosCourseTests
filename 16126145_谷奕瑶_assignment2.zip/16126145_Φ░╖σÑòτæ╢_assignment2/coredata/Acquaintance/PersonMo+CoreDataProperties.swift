//
//  PersonMo+CoreDataProperties.swift
//  Acquaintance
//
//  Created by zjajgyy on 2016/11/29.
//  Copyright © 2016年 zjajgyy. All rights reserved.
//

import Foundation
import CoreData


extension PersonMo {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<PersonMo> {
        return NSFetchRequest<PersonMo>(entityName: "PersonMO");
    }

    @NSManaged public var name: String?
    @NSManaged public var notes: String?
    @NSManaged public var phone: String?
    @NSManaged public var email: String?
    @NSManaged public var photo: NSData?
    @NSManaged public var category: String?

}
