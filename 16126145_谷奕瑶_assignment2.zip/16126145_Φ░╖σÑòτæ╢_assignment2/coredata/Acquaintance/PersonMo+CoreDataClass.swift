//
//  PersonMo+CoreDataClass.swift
//  Acquaintance
//
//  Created by zjajgyy on 2016/11/29.
//  Copyright © 2016年 zjajgyy. All rights reserved.
//

import Foundation
import CoreData

@objc(PersonMo)
public class PersonMo: NSManagedObject {

}
